package model;

/**
 * Created by User on 04/02/2018.
 */

public enum State {
    Running,
    BallLoss,
    GameOver,
    Won,
    Pause,
    Quit;

    State(){
    }
}
